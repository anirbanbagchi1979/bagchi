module.exports = function(service) {


	/**
	 *  The file samples.txt in the archive that this file was packaged with contains some example code.
	 */


	service.post('/mobile/custom/sendemail/sendEmail', function(req,res) {
		var result = {};
		res.send(201, result);
	});

};
